username-123<br/>
passward-123<br/>

Install node<br/>
Install express<br/>
Cd init<br/>
Node index.js<br/>
Cd..<br/>
Install nodemon<br/>
Nodemon app.js
